using UnityEngine;

namespace TexDrawLib
{
    [AddComponentMenu("TEXDraw/Supplemets/TEXSup Transform Follow")]
    [TEXSupHelpTip("This component has been obsoleted")]
    public class TEXSupTransformFollow : TEXDrawMeshEffectBase
    {
        public override void ModifyMesh(Mesh m)
        {
        }
    }
}