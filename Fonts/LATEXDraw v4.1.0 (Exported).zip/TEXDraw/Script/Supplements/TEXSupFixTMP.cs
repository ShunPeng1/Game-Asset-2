using UnityEngine;

namespace TexDrawLib
{
	[AddComponentMenu("TEXDraw/Supplemets/TEXSup Fix TMP", 16), ExecuteInEditMode]
	[TEXSupHelpTip("This component has been obsoleted")]
	public class TEXSupFixTMP : TEXDrawMeshEffectBase
	{
		
		public override void ModifyMesh(Mesh m)
		{
		}
	}
}