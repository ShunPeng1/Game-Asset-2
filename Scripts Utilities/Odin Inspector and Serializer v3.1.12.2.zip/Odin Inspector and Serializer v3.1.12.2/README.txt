Before you import this package, you go to Project folder -> Packages -> open file manifest.json and add some below lines:
    "com.unity.mathematics": "1.2.6",

NOTE: if your manifest.json file already had these lines, you just need to change the version of it.