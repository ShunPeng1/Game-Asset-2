public class BaseClassImpl: BaseClass { 
    //2. make change here and let it hot-reload
}