using UnityEngine;

public class BaseClass {
    public void TestCall() {
        Debug.Log("Test Call");
    }
}