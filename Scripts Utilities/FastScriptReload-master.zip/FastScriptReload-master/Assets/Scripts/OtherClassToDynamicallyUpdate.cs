﻿using UnityEngine;

public class OtherClassToDynamicallyUpdate: MonoBehaviour
{
    void Update()
    {
        Debug.Log("OtherClassToDynamicallyUpdate - Testing - 1587a");
        // TestNew();
    }

    void TestNew()
    {
        Debug.Log("Test Added new method - 1");
    }
}