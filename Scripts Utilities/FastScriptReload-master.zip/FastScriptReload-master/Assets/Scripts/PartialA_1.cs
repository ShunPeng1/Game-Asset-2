public partial class PartialA
{
    public string VariableInOtherPartialFile = "VariableInOtherPartialFile";
}