using UnityEngine;

namespace AsmB
{
    public class TestChild : MonoBehaviour
    {
        protected int _protectedField;
    }
}
