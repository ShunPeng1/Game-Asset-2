using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InheritanceTestChild : MonoBehaviour
{
    protected int _protectedField;
    

}