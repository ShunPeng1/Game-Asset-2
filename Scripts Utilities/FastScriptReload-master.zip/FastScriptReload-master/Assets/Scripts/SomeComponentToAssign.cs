public class SomeComponentToAssign
{
    public ThisRewritingMissingAncestorTest testInstance;
}