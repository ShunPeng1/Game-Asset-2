public class AccessProtectedMemberInBaseClass_BaseClass
{
    protected internal int TestInt = 3;
}