﻿using UnityEngine;

public class TestExtensionObj
{
    public void TestCall()
    {
        Debug.Log("TestCall 1z");
    }
}