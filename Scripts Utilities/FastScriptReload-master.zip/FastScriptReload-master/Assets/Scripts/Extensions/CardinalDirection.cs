
    public enum CardinalDirection 
    {
        None,
        North,
        South,
        West,
        East
    }